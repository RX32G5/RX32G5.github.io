#!/bin/bash

while true; do
    clear
    echo "Menu:"
    echo "1. Afficher la date"
    echo "2. Afficher l'heure"
    echo "3. Quitter"
    echo " "
    read -p "Veuillez entrer le numéro de votre choix : " choix
    echo " "
    case $choix in
        1)
            date
            read -p "Appuyez sur Entrée pour continuer..."
            ;;
        2)
            heure=$(date +%H:%M:%S)
            echo "L'heure actuelle est : $heure"
            read -p "Appuyez sur Entrée pour continuer..."
            ;;
        3)
            echo "Au revoir !"
            break
            ;;
        *)
            echo "Choix invalide. Veuillez entrer un numéro valide."
            read -p "Appuyez sur Entrée pour continuer..."
            ;;
    esac
done
